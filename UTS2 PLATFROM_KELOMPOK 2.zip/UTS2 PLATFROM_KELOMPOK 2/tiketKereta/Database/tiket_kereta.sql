-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 03, 2022 at 05:23 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tiket_kereta`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id_class` varchar(10) NOT NULL,
  `nama_class` varchar(10) NOT NULL,
  `gerbong` varchar(5) NOT NULL,
  `tarif` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id_class`, `nama_class`, `gerbong`, `tarif`) VALUES
('BNS01', 'Bisnis', '1', 250000),
('E01', 'Ekonomi', '1', 50000),
('EX01', 'Eksekutif', '3', 100000);

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id_jadwal` varchar(10) NOT NULL,
  `nama_kereta` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu_datang` time NOT NULL,
  `waktu_tiba` time NOT NULL,
  `asal` varchar(20) NOT NULL,
  `tujuan` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `id_class` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jadwal`
--

INSERT INTO `jadwal` (`id_jadwal`, `nama_kereta`, `tanggal`, `waktu_datang`, `waktu_tiba`, `asal`, `tujuan`, `status`, `id_class`) VALUES
('B612', 'Kereta 5466', '2022-12-06', '18:13:00', '21:13:00', 'Surabaya', 'Jakarta', 'tersedia', 'E01'),
('C123', 'Kereta Kencana', '2022-12-05', '16:51:00', '18:51:00', 'Bandung', 'Surabaya', 'tersedia', 'E01'),
('J453', 'Rosevelt', '2022-12-06', '16:46:00', '17:59:00', 'Bandung', 'Jakarta', 'tidak tersedia', 'E01'),
('JB234', 'Nusan', '2022-12-05', '22:17:00', '13:29:00', 'Jakarta', 'Bengawan', 'tersedia', 'EX01'),
('K9', 'Kuno', '2022-12-05', '17:51:00', '20:51:00', 'Surabaya', 'Solo', 'tidak tersedia', 'EX01'),
('L009', 'Utama', '2022-12-14', '19:27:00', '12:23:00', 'Surabaya', 'Bandung', 'tersedia', 'EX01');

-- --------------------------------------------------------

--
-- Table structure for table `kursi`
--

CREATE TABLE `kursi` (
  `no_kursi` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kursi`
--

INSERT INTO `kursi` (`no_kursi`) VALUES
('A01'),
('A02'),
('A03'),
('A04'),
('A05'),
('A06'),
('A07'),
('A08'),
('A09'),
('B01'),
('B02'),
('B03'),
('B04'),
('B05'),
('B06'),
('B07'),
('B08'),
('B09'),
('C01'),
('C02'),
('C03'),
('C04'),
('C05'),
('C06'),
('C07'),
('C08'),
('C09'),
('D01'),
('D02'),
('D03'),
('D04'),
('D05'),
('D06'),
('D07'),
('D08'),
('D09');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `idMember` varchar(16) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `noTelepon` int(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`idMember`, `nama`, `noTelepon`, `username`, `password`) VALUES
('0000000000000000', 'admin', 0, 'admin', '$2y$10$SKYhW4AmqvYDopOXCKDjXOzboVCgHcLdJERVn8nRajecqpBhjgJ7e'),
('1231231231232312', 'alek', 123, 'alek', '$2y$10$10COPi6mncc2YZ2SBQTeKuQDCM07TuR7iHy1BlnR4rH/btu3AvMa2'),
('12736214', 'INKA', 908383, 'inka', '$2y$10$rPDPnOwKdJ4D/yhNcjJ/IuAkRfLmnlBPCjk3F76ZAecZCxUuuaIY.'),
('1292819278916289', 'hiko', 12133, 'hiko', '$2y$10$i7yhbyg69SSdCAf7IkUywuWWG24C8viB7TaS6OWlSBQQsrnYZJ4zm'),
('172235821', 'fransiska', 2147483647, 'putri', '$2y$10$p7YlTF01bZ5harVBim8Sw.A2bsoXsPo7zdQb5.Of9I8Y5nefoAPnu'),
('3216549873216549', 'adsldfsdjg', 0, 'asd', '$2y$10$M495B3HXSySFl3WUlAD2SuC4BLw6Qz9bErbXoD6zfkY1E5hpd2dLq');

-- --------------------------------------------------------

--
-- Table structure for table `pemesanan`
--

CREATE TABLE `pemesanan` (
  `no_receipt` int(11) NOT NULL,
  `no_kursi` varchar(10) NOT NULL,
  `id_jadwal` varchar(10) NOT NULL,
  `id_penumpang` varchar(16) DEFAULT NULL,
  `nama_penumpang` varchar(30) DEFAULT NULL,
  `total_harga` int(20) DEFAULT NULL,
  `id_member` varchar(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pemesanan`
--

INSERT INTO `pemesanan` (`no_receipt`, `no_kursi`, `id_jadwal`, `id_penumpang`, `nama_penumpang`, `total_harga`, `id_member`) VALUES
(1, 'A01', 'B612', NULL, NULL, 50000, '1231231231232312'),
(7, 'A02', 'B612', '', '', 50000, '1231231231232312'),
(8, 'A01', 'B612', '12', 'a', 50000, '1231231231232312'),
(9, 'A06', 'B612', '', '', 50000, '1231231231232312'),
(10, 'A03', 'B612', '45', 'b', 50000, '1231231231232312'),
(11, 'A01', 'B612', '', '', 50000, '1231231231232312'),
(12, 'B08', 'B612', '', '', 50000, '1231231231232312'),
(13, 'A01', 'JB234', '', '', 100000, '1231231231232312'),
(14, 'A04', 'JB234', '34522', 'Anjay', 100000, '1231231231232312'),
(15, 'A02', 'JB234', '8888', 'asikue', 200000, '1231231231232312'),
(16, 'A02', 'JB234', '', '', 100000, '1231231231232312'),
(18, 'A05', 'JB234', '445566', 'aleksis', 200000, '1231231231232312'),
(19, 'B01', 'L009', '566', 'snces', 200000, '1231231231232312');

-- --------------------------------------------------------

--
-- Table structure for table `tiket`
--

CREATE TABLE `tiket` (
  `id_booking` int(11) NOT NULL,
  `no_kursi` varchar(10) NOT NULL,
  `id_jadwal` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id_class`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id_jadwal`),
  ADD KEY `id_class` (`id_class`);

--
-- Indexes for table `kursi`
--
ALTER TABLE `kursi`
  ADD PRIMARY KEY (`no_kursi`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`idMember`);

--
-- Indexes for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD PRIMARY KEY (`no_receipt`),
  ADD KEY `id_member` (`id_member`),
  ADD KEY `id_jadwal` (`id_jadwal`),
  ADD KEY `no_kursi` (`no_kursi`);

--
-- Indexes for table `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id_booking`),
  ADD KEY `no_kursi` (`no_kursi`),
  ADD KEY `id_jadwal` (`id_jadwal`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pemesanan`
--
ALTER TABLE `pemesanan`
  MODIFY `no_receipt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`id_class`) REFERENCES `class` (`id_class`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pemesanan`
--
ALTER TABLE `pemesanan`
  ADD CONSTRAINT `pemesanan_ibfk_1` FOREIGN KEY (`id_member`) REFERENCES `member` (`idMember`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pemesanan_ibfk_3` FOREIGN KEY (`id_jadwal`) REFERENCES `jadwal` (`id_jadwal`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pemesanan_ibfk_4` FOREIGN KEY (`no_kursi`) REFERENCES `kursi` (`no_kursi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
