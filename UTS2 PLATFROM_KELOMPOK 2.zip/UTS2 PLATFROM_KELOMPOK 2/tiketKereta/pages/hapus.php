<?php
// include database connection file
require '../config/config.php';
 
// Get id from URL to delete that user
$id = $_GET['id_jadwal'];
 
// Delete user row from table based on given id
$result = mysqli_query($conn, "DELETE FROM jadwal WHERE id_Jadwal= '$id'");
 
// After delete redirect to Home, so that latest user list will be displayed.
header("Location:data_Jadwal.php");
?>