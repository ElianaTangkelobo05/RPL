<?php
session_start();

require '../config/config.php';

$isAdmin = false;
$isLogin = false;
if (isset($_SESSION['login'])) {
    $isAdmin = $_SESSION['admin'];
    $isLogin = $_SESSION['login'];
}

$sources = getAsal();
$destinations = getTujuan();

if (isset($_POST['submit'])) {
    // var_dump($_POST);
    // return;
    header("Location: tiket.php?asal=" . $_POST['asal'] . "&tujuan=" . $_POST['tujuan'] . "&tanggal=" . $_POST['tanggal']);
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styleNav.css">
    <title>Pesan Tiket</title>
</head>
<body>
    <form action="" method="POST">
        <!--Boostrab Navigasi Start-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
            <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
            <div class="container-fluid">
                <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse">
                    <ul>
                        <li><a href="home.php">Home </a></li>
                        <li><a href="about.php">About</a></li>
                        <li><a href="layanan.php">Service</a></li>
                    </ul>
                    <?php if (!$isLogin) : ?>
                    <div class="content">
                        <button class="cn"><a href="registrasi.php">REGISTER</a></button>
                    </div>
                    <div class="content2">
                        <button class="cn"><a href="login.php">LOGIN</a></button>
                    </div>
                    <?php else : ?>
                    <div class="content">
                        <button class="cn"><a href="logout.php">Logout</a></button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </nav>
        <br>
        <div class="check-in">
            <h3>Pemesanan Tiket Kereta Api</h3>
            <p></p>

            <form action="" method="post">
                <div class="container row">
                    <div class="col-md-4">
                        <label for="inputZip" class="form-label">Stasiun Asal</label>
                        <select style="border-color:#A800A9;" class="form-select" aria-label="Default select example"
                            name="asal">
                            <?php foreach ($sources as $source) : ?>
                            <option value="<?php echo $source['asal'] ?>"><?php echo $source['asal'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label for="inputZip" class="form-label">Stasiun Tujuan</label>
                        <select style="border-color:#A800A9;" class="form-select" aria-label="Default select example"
                            name="tujuan">
                            <?php foreach ($destinations as $destination) : ?>
                            <option value="<?php echo $destination['tujuan'] ?>"><?php echo $destination['tujuan'] ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="container row" style="margin-left: 65%; margin-top: -69px">
                    <div class="col-md-4">
                        <label for="inputAddress" class="form-label">Tanggal</label>
                        <input style="border-color:#A800A9;" type="date" class="form-control" name="tanggal"
                            placeholder="30/11/2022">
                    </div>
                </div>

                <button style="float: right; margin-right: 3rem; margin-top: 3rem;" type="submit"
                    class="btn btn-primary" name="submit">Cari</button>
            </form>
        </div>
        <br>
    </form>

    <?php if ($isLogin) : ?>
    <a class="btn btn-primary" href="detailPemesanan.php?idMember=<?php echo $_SESSION['user'] ?>">Lihat Jadwal</a>
    <?php //else : ?>
    <!-- <a style="float: right; margin-right: 22rem; margin-top: -7rem;" class="btn btn-primary" href="cariJadwal.php">Lihat
        Jadwal</a> -->
    <?php endif; ?>
</body>

</html>