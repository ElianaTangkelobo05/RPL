<?php
session_start();
require '../config/config.php';

if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}
// $jadwals = showJadwal();
$id = $_GET['id_tiket'];
$asal = $_GET['asal'];
$tujuan = $_GET['tujuan'];
$tanggal = $_GET['tanggal'];
$jadwals = showTiket($asal, $tujuan, $tanggal); 
$jadwal = showTiketId($id)[0];

$member = getMember($_SESSION)[0];
$seats = getSeat();
$reserved = getKursiReserved($jadwal['id_jadwal']);
$availSeat = getKursiReserved($jadwal['id_jadwal']);

$resLen = count($reserved);

for ($i = 0; $i < count($seats) - $resLen; $i++) {
  $reserved[]['no_kursi'] = '';
}

$maxLength = count($seats) > count($reserved) ? count($seats) : count($reserved);

// var_dump($reserved); return;
// var_dump($reserved); return;

if (isset($_POST['submit'])) {
  if (pemesanan($_POST, $jadwals, $member) > 0) {
    echo "<script>
            alert('Berhasil memesan tiket')
            document.location.href = 'detailPemesanan.php?idMember=" . $_SESSION['user'] . "';
          </script>";
  } else {
    echo "<script>
            alert('Gagal memesan tiket')
          </script>";
  }
  // pemesanan($_POST, $jadwals[0], $member[0]);
  // var_dump($jadwals);
  // var_dump($_POST['seat'][0]);
  // pemesanan($_POST['']);
}

?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="../css/tiket.css">

  <title>Pesan Tiket</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" 
  rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
  <nav class="navbar navbar-expand-lg">
    <div class="d-flex header">
      <button class="navbar-brand" style="border: none;
  background-color: #d825df;" onclick="history.back()">
        <svg version="1.0" xmlns="http://www.w3.org/2000/svg" width="50.000000pt" height="50.000000pt" viewBox="0 0 50.000000 50.000000" preserveAspectRatio="xMidYMid meet">

          <g transform="translate(0.000000,50.000000) scale(0.100000,-0.100000)" fill="#fff" stroke="none">
            <path d="M215 330 l-80 -80 82 -82 c45 -45 86 -79 90 -75 4 4 -26 41 -67 82
l-74 75 72 73 c39 40 72 76 72 80 0 18 -21 2 -95 -73z" />
          </g>
        </svg>
      </button>

      <div class="infTitle">
        <h4><?php echo $asal ?> - <?php echo $tujuan ?></h4>
        <p class="m-0">
          <?php echo $tanggal ?>
        </p>
      </div>
    </div>
  </nav>

  <div class="tiket container mt-4 rounded-1">
    <img class="mb-2" src="../img/logo.png" alt="KA Sadhar">
    <div class="detail l1">
      <p class="kereta">
        <?php echo $jadwal['nama_kereta']; ?>
      </p>
      <div class="rightSide">
        <p class="kereta"> <?php echo $jadwal['tarif']; ?>,-</p>
      </div>
    </div>
    <div class="detail l2">
      <p class="kelas"><?php echo $jadwal['nama_class'] ?> (<?php echo $jadwal['id_class'] ?>)</p>
      <div class="rightSide">
        <?php if ($jadwal['status'] == 'tersedia') : ?>
          <p class="kelas status text-success fw-bolder">Tersedia</p>
        <?php else : ?>
          <p class="kelas status text-danger fw-bolder">Tidak Tersedia</p>
        <?php endif; ?>
      </div>
    </div>
    <div class="detail l3">
      <p class="kota"><?php echo $jadwal['asal']; ?></p>
      <div class="rightSide">
        <p class="kota"><?php echo $jadwal['tujuan']; ?></p>
      </div>
    </div>
    <div class="detail l4">
      <p class="waktu"><?php echo $jadwal['waktu_datang']; ?></p>
      <div class="rightSide">
        <p class="waktu"><?php echo $jadwal['waktu_tiba'] ?></p>
      </div>
    </div>
    <div class="detail l5">
      <p><?php echo $jadwal['tanggal']; ?></p>
      <div class="rightSide">
        <p><?php echo $jadwal['tanggal']; ?></p>
      </div>
    </div>
    <div class="durasi">
      <div class="center">
        <svg version="1.0" xmlns="http://www.w3.org/2000/svg" width="50.000000pt" height="50.000000pt" viewBox="0 0 50.000000 50.000000" preserveAspectRatio="xMidYMid meet">
          <g transform="translate(0.000000,50.000000) scale(0.100000,-0.100000)" fill=gray stroke="none">
            <path d="M182 398 c-10 -10 2 -27 55 -80 l67 -68 -67 -68 c-61 -61 -66 -70
  -52 -82 14 -12 26 -3 98 68 l82 82 -80 80 c-44 44 -82 80 -85 80 -3 0 -11 -5
  -18 -12z" />
          </g>
        </svg>

        <?php if (strlen($jadwal['durasi']) == 8) : ?>
          <p>Durasi <?php echo substr($jadwal['durasi'], 0, -6) ?>j <?php echo substr($jadwal['durasi'], 3, -3) ?>m</p>
        <?php else : ?>
          <p>Durasi <?php echo substr($jadwal['durasi'], 1, -6) ?>j <?php echo substr($jadwal['durasi'], 4, -3) ?>m</p>
        <?php endif; ?>
        <!-- <p>Durasi 2j 40m</p> -->
      </div>
    </div>
  </div>
  <!-- </a> -->

  <div class="container mt-4">
    <h6>Data Pemesan</h6>
  </div>
  <div class="data-pemesan container">
    <div class="row">
      <div class="mb-3 col-4">
        <label for="namaMember" class="form-label">Nama Lengkap</label>
        <input class="form-control" type="text" value="<?php echo $member['nama'] ?>" aria-label="readonly input example" readonly>
      </div>

      <div class="mb-3 col-4">
        <label for="telepon" class="form-label">No Telepon</label>
        <input class="form-control" type="text" value="<?php echo $member['noTelepon'] ?>" aria-label="readonly input example" readonly>
      </div>
    </div>

    <div class="row">
      <div class="input-group mb-3 col-3">
        <label for="username" class="form-label">Username</label>
        <div class="input-group">
          <span class="input-group-text" id="basic-addon1">@</span>
          <input class="form-control" type="text" value="<?php echo $member['username'] ?>" aria-label="readonly input example" readonly>
        </div>
      </div>
    </div>
  </div>

  <form action="" method="post">
    <div class="container mt-4">
      <h6>Detail Penumpang</h6>
    </div>
    <div class="data-penumpang container">
      <div class="row">
        <div class="mb-3 col-4">
          <label for="penumpang" class="form-label">Nama Lengkap</label>
          <input type="text" class="form-control" id="penumpang" placeholder="Masukan nama" name="nama_penumpang">
        </div>

        <div class="col-6"></div>

        <div class="mb-3 col-4">
          <label for="telepon" class="form-label">NIK</label>
          <input type="number" class="form-control" id="telepon" placeholder="Masukan NIK" name="id_penumpang">
        </div>
      </div>

      <!-- <div class="tambah-penumpang">
        <button class="btn-purple">Tambah Sebagai Penumpang</button>
      </div> -->
    </div>

    <div class="container mt-4">
      <h6>Pilih Kursi</h6>
    </div>
    <div class="kursi container">
      <div class="row gap-3 mt-4">
        <?php for ($i = 0; $i < $maxLength; $i++) : ?>
          <div class="col-1">
            <?php if (mb_substr($seats[$i]['no_kursi'], 0, 1) == 'A') : ?>
              <input  value="<?php echo $seats[$i]['no_kursi'] ?>" type="checkbox" class="btn-check" name="options-outlined" id="
              <?php echo $seats[$i]['no_kursi'] ?>" autocomplete="off">
              <label class="btn btn-outline-success" for="<?php echo $seats[$i]['no_kursi'] ?>">
              <?php echo $seats[$i]['no_kursi'] ?></label>
            <?php endif; ?>

            <?php if (mb_substr($seats[$i]['no_kursi'], 0, 1) == 'B') : ?>
              <input  value="<?php echo $seats[$i]['no_kursi'] ?>" type="checkbox" class="btn-check" name="options-outlined" id="
              <?php echo $seats[$i]['no_kursi'] ?>" autocomplete="off">
              <label class="btn btn-outline-success mb-5" for="<?php echo $seats[$i]['no_kursi'] ?>">
              <?php echo $seats[$i]['no_kursi'] ?></label>
            <?php endif; ?>

            <?php if (mb_substr($seats[$i]['no_kursi'], 0, 1) == 'C') : ?>
              <input  value="<?php echo $seats[$i]['no_kursi'] ?>" type="checkbox" class="btn-check" name="options-outlined" id="
              <?php echo $seats[$i]['no_kursi'] ?>" autocomplete="off">
              <label class="btn btn-outline-success" for="<?php echo $seats[$i]['no_kursi'] ?>">
              <?php echo $seats[$i]['no_kursi'] ?></label>
            <?php endif; ?>

            <?php if (mb_substr($seats[$i]['no_kursi'], 0, 1) == 'D') : ?>
              <input  value="<?php echo $seats[$i]['no_kursi'] ?>" type="checkbox" class="btn-check" name="options-outlined" id="
              <?php echo $seats[$i]['no_kursi'] ?>" autocomplete="off">
              <label class="btn btn-outline-success" for="<?php echo $seats[$i]['no_kursi'] ?>">
              <?php echo $seats[$i]['no_kursi'] ?></label>
            <?php endif; ?>
          </div>
        <?php endfor; ?>

      </div>
    </div>

    <div class="container mt-4">
      <select class="form-select" aria-label="Default select example" name="seat">
        <?php foreach($availSeat as $avail) : ?>
          <option value="<?= $avail['no_kursi'] ?>"><?= $avail['no_kursi'] ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="tambah-penumpang container mb-5">
      <button type="submit" name="submit" class="btn-purple">Pesan</button>
    </div>
  </form>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>

</html>