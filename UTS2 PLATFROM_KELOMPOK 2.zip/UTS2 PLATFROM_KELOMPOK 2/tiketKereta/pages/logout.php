<?php 
//untuk menghilangkan session agar user dapat keluar dari sistem
session_start();
$_SESSION =[];
session_unset();
session_destroy();
header("Location: login.php");
exit;
?>