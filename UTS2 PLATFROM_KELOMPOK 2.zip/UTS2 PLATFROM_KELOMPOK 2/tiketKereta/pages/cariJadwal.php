<?php

require '../config/config.php';

$isAdmin = false;
$isLogin = false;
if (isset($_SESSION['login'])) {
  $isAdmin = $_SESSION['admin'];
  $isLogin = $_SESSION['login'];
}

if(isset($_POST['submit'])) {
  header("Location: jadwalNonMember.php?namaPenumpang=".$_POST['nama']);
}
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="../css/styleNav.css">
  <title>Bootstrap demo</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
    <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
    <div class="container-fluid">
      <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse">
        <ul>
          <li><a href="home.php">Home </a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="layanan.php">Layanan</a></li>
        </ul>
        <?php if (!$isLogin) : ?>
          <div class="content">
            <button class="cn"><a href="registrasi.php">REGISTER</a></button>
          </div>
          <div class="content2">
            <button class="cn"><a href="login.php">LOGIN</a></button>
          </div>
        <?php else : ?>
          <div class="content">
            <button class="cn"><a href="logout.php">Logout</a></button>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </nav>
  <br>

  <div class="container">
    <form action="" method="post">
      <div class="mb-3">
        <label for="nama" class="form-label">Nama</label>
        <input type="text" class="form-control" id="nama" placeholder="Masukan nama" name="nama">
      </div>
      <div>
        <button class="btn btn-success" type="submit" name="submit">Cari</button>
      </div>
    </form>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</body>

</html>