<?php
session_start();


require '../config/config.php';
$isAdmin = true;
if (!isset($_SESSION['login'])) {
    if (!isset($_SESSION['admin'])) {
        header("Location: login.php");
        exit;
    }
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <style>
        table,
        tr,
        td {
            border: 2px solid black;
        }

        thead {
            background-color: #cccddd;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styleNav.css">

</head>

<body id="home">
    <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
        <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
        <div class="container-fluid">
            <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul>
                    <!-- <li><a href="home.php">Home</a></li> -->
                    <li><a href="data_Jadwal.php">Data Jadwal</a></li>
                    <li><a href="tambahJadwal.php">Tambah Jadwal</a></li>

                </ul>
                <div class="content">
                    <button class="cn"><a href="logout.php">Logout</a></button>
                </div>
            </div>
        </div>
    </nav>
    <br>
    <br>
    <br>
    <h3 align="center">SELAMAT ANDA LOGIN SEBAGAI ADMIN :)</h3>
</body>

</html>
