<?php
session_start();

$isAdmin = false;
$isLogin = false;
if (isset($_SESSION['login'])) {
    $isAdmin = $_SESSION['admin'];
    $isLogin = $_SESSION['login'];
}

?>


<!doctype html>
<html lang="en">

<head>
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <!-- My css -->
    <link rel="stylesheet" href="../css/styleNav.css">
</head>

<body>
    <!--Boostrab Navigasi Start-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top" style="height: 80px">
        <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
        <div class="container-fluid">
            <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
            <?php if ($isAdmin) : ?>
                        <ul>
                            <li><a href="home.php">Home</a></li>
                            <li><a href="data_Jadwal.php">Data Jadwal</a></li>
                            <!-- <li><a href="logout.php">Logout</a></li> -->
                        </ul>
                    <?php else : ?>
                        <ul>
                            <li><a href="home.php">Home </a></li>
                            <li><a href="about.php">About</a></li>
                            <li><a href="layanan.php">Service</a></li>
                        </ul>
                    <?php endif; ?>

                    <?php if (!$isLogin) : ?>
                        <div class="content">
                            <button class="cn"><a href="registrasi.php">REGISTER</a></button>
                        </div>
                        <div class="content2">
                            <button class="cn"><a href="login.php">LOGIN</a></button>
                        </div>
                    <?php else : ?>
                        <div class="content">
                            <button class="cn"><a href="logout.php">Logout</a></button>
                        </div>
                    <?php endif; ?>
            </div>
        </div>
    </nav>
    <br>
    <!-- jumbotron start -->
    <section class="jumbotron text-center">
        <h2 style="margin-top:10px">PT KERETA API SADHAR</h2>
        <br>
        <img src="kereta/kereta.jpg" alt="" width="700">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
            <path fill="#ffffff" fill-opacity="1"
                d="M0,160L40,138.7C80,117,160,75,240,64C320,53,400,75,480,122.7C560,171,640,245,720,240C800,235,880,149,960,122.7C1040,96,1120,128,1200,149.3C1280,171,1360,181,1400,186.7L1440,192L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z">
            </path>
        </svg>
    </section>
    <!-- jumbotron end -->
    <!-- Layout About Start -->
    <section id="About">
        <div class="container">
            <div class="row text-center">
                <div class="col" style="margin-top:-250px">
                    <h2>About US</h2>
                </div>
            </div>
            <div class="card" style="margin-top:-198px">
                <div class="card-body">
                    <blockquote class="blockquote mb-0">
                        <p>Kereta Api Sadhar, merupakan sebuah jasa penyedia transportasi yang memberikan penawaran
                            pelayanan yang cepat dengan jangkauan yang luas. Sistem Kereta Api Sadhar ini merupakan
                            sistem yang akan digunakan untuk mempermudah proses penjualan tiket kereta api dengan
                            menyediakan semua jenis class yang ada di PT Kereta Api Sadhar seperti class ekonomi,
                            bisnis,
                            dan eksekutif</p>
                        <footer class="blockquote-footer">PT KERRTA API SADHAR <cite title="Source Title"></cite>
                        </footer>
                    </blockquote>
                </div>
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320" style="margin-top:-120px">
            <path fill="#e287e6" fill-opacity="1"
                d="M0,288L40,266.7C80,245,160,203,240,192C320,181,400,203,480,208C560,213,640,203,720,218.7C800,235,880,277,960,293.3C1040,309,1120,299,1200,277.3C1280,256,1360,224,1400,208L1440,192L1440,320L1400,320C1360,320,1280,320,1200,320C1120,320,1040,320,960,320C880,320,800,320,720,320C640,320,560,320,480,320C400,320,320,320,240,320C160,320,80,320,40,320L0,320Z">
            </path>
        </svg>

    </section>
    <br>
    <br>

    <!-- Layout About end-->
    <!-- jumbotron end -->

    <!-- project Start-->
    <section id="Project">
        <div class="container">
            <div class="row text-center">
                <div class="col">
                    <h2>CLASS</h2>

                </div>
            </div>
            <div class="row" style="margin-top:50px">
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="../img/kursi.jpeg" class="card-img-top">
                        <div class="card-body">
                            <p class="card-text">Class "EKONOMI"</p>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="../img/kursi2.jpg" class="card-img-top" alt="project 1">
                        <div class="card-body">
                            <p class="card-text">Class "EKSEKUTIF"</p>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 mb-3">
                    <div class="card ">
                        <img src="../img/kursi3.jpg" class="card-img-top" alt="" style="height : 195px">
                        <div class="card-body">
                            <p class="card-text">Class "BISNIS"</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-10">

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Project end -->
    <!-- Footer Contact Me Start -->
    <footer class="bg-dark text-white text-center p-5 mt-5" style="height: 30rem;">

        <div class="container ">
            <div class="row text-center">
                <div class="col">
                    <h3>Contact US</h3>
                    <p class="m-4"> Nomor : 081344276698</p>
                    <p>IG : keretaApiSadhar</p>
                    <p>Email : PTkeretaApiSadhar.com</p>
                    <br></br>
                    <p class="text-center mt-5">Silahkan hubungi kami untuk mendapat informasi lebih tentang pemesanan tiket kereta Api.</p>

                </div>
            </div>
            <div class="row">
    </footer>
    <!-- Footer Contact end -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>
</body>

</html>