<?php
session_start(); //untuk menjalankan session
//jika user telah login, maka akan langsung dipindahkan ke halaman utama
require '../config/config.php';

if (isset($_SESSION['login'])) {
    header("Location: layanan.php");
    exit;
}

if(isset($_POST['submit'])) {
    // var_dump(getIdMemberByUsername($_POST['username']));
    // return;
    if(login($_POST) > 0) {
        if($_POST['username'] == 'admin') {
            $_SESSION["login"] = true; //membuat variable sission login yang isinya boolean true. Ini akan berfungsi untuk mencek session ditiap" halaman dimana jika sessionnya ada berarti user berhasil login
            $_SESSION["admin"] = false;
            $_SESSION['user'] = getIdMemberByUsername($_POST['username']);
            echo "<script>
                    alert('Welcome admin')
                    document.location.href = './admin.php';
                </script>";
        } else {
            $_SESSION["login"] = true;
            $_SESSION["admin"] = false;
            $_SESSION['user'] = getIdMemberByUsername($_POST['username']);
            echo "<script>
                    alert('Welcome ".$_POST['username']."')
                    document.location.href = './layanan.php';
                </script>";
        }
    } else {
        echo "<script>
                alert('Username atau Password tidak tepat')
            </script>";
    }
    
    // var_dump(login($_POST));
    // return;
}


// if (isset($_POST["submit"])) { //jika tombol login diklik maka
//     $username = $_POST["username"]; //tangkap username denagn method post dan simpan data username kedalam variabel $username
//     $password = $_POST["password"];

//     //cek apakah ada username sudah ada didalam database
//     $result = mysqli_query($conn, "SELECT * FROM member WHERE username = '$username'");

//     //cek username
//     if (mysqli_num_rows($result) == 1) { //untuk meghitung ada berapa baris yang dikembalikan dari fungsi select diatas
//         //jika ada, nilainya 1 jika tidak maka nilainya 0

//         //jika ada, cek passwordnya berdasarkan username
//         $row = mysqli_fetch_assoc($result); //jadi didalam variabelrow sudah ada isi datanya yaitu username dan pass yang telah diacak
//         // cek jika user login sebagai admin

//         if (password_verify($password, $row["password"])) { //password_verify mencek sebuah string itu sama ga dengan pass hash nya. Parameternya ada 2, yaitu string yang belum diacak dan String yang telah diacak

//             //setting sesion agar pada tiap-tiap halaman ada ga sessionnya jika ada berarti user berhasil login
//             $_SESSION["login"] = true; //membuat variable sission login yang isinya boolean true. Ini akan berfungsi untuk mencek session ditiap" halaman dimana jika sessionnya ada berarti user berhasil login
//             $_SESSION["admin"] = false;
//             $_SESSION['user'] = $row['idMember'];
//             header("Location: layanan.php"); // jika berhasil diverivikasi maka perbolehkan user masuk ke dlaam sistem pada halaman index.php
//         }
//         //login admin
//         $admin = mysqli_query($conn, "SELECT * FROM member WHERE username = 'admin'");
//         if (mysqli_num_rows($admin) == 1) {
//             $baris = mysqli_fetch_assoc($admin);
//             if (password_verify($password, $baris["password"])) {
//                 $_SESSION["login"] = true;
//                 $_SESSION["admin"] = true;
//                 header("Location: admin.php");
//             }
//             //jika pass tidak sama dengan ada yang ditabase maka ada  pesan kesalahan 
//             $error = true;
//         }
//     }
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styleNav.css">
    <link rel="stylesheet" href="../css/style.css">
    <title>Document</title>
</head>
<body>
    <!--Boostrab Navigasi Start-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
        <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
        <div class="container-fluid">
            <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul>
                    <li><a href="home.php">Home </a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="layanan.php">Service</a></li>
                </ul>
                <div class="content">
                    <button class="cn"><a href="registrasi.php">REGISTER</a></button>
                </div>
            </div>
        </div>
    </nav>
    <br>
    <div class="container">
        <form action="" method="POST" class="login-email">
            <p style="font-size:2rem; font-weight:850;" align="center">LOGIN</p> <br>
            <div class="input-group"><input type="text" name="username" id="username" placeholder="Username"></div>
            <div class="input-group"><input type="password" name="password" id="password" placeholder="Password"></div>
            <div class="input-group"><button class="btn" type="submit" name="submit">login</button></div> <br>
            <P class="login-register-text">Dont Have an Account?<a href="registrasi.php">Register</a></P>
        </form>
</body>

</html>
</body>

</html>