<?php
session_start();

require '../config/config.php';

if (!isset($_SESSION['login'])) {
    header("Location: login.php");
    exit;
}

if (isset($_POST['submit'])) {
    if (tambahJadwal($_POST) > 0) {
        echo "<script>
                alert('Jadwal berhasil ditambah')
                document.location.href = 'data_Jadwal.php';
            </script>";
    } else {
        echo "<script>
                alert('Jadwal gagal ditambah')
            </script>";
    }
}

$classes = getClass();
?>


<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <link rel="stylesheet" href="../css/styleNav.css">
    <title>Tambah Jadwal</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
        <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
        <div class="container-fluid">
            <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul>
                    <!-- <li><a href="home.php">Home </a></li> -->
                    <li><a href="data_Jadwal.php">Data Jadwal</a></li>
                    <li><a href="tambahJadwal.php" style="color: #d825df;">Tambah Jadwal</a></li>
                </ul>
                <div class="content">
                    <button class="cn"><a href="admin.php">Back</a></button>
                </div>
                <div class="content2">
                    <button class="cn"><a href="logout.php">Logout</a></button>
                </div>
            </div>
        </div>
    </nav>
    <br /><br />

    <h4 style="text-align:center;">Tambah Jadwal</h4>

    <div class="container">
        <form class="row g-3" action="" method="POST" style="margin-top:1rem;">
            <div class="col-md-4">
                <label for="inputEmail4" class="form-label">Id Jadwal</label>
                <input style="border-color:#A800A9;" type="text" class="form-control" name="id" placeholder="J1452">
            </div>
            <div class="col-md-4">
                <label for="inputPassword4" class="form-label">Nama Kereta</label>
                <input style="border-color:#A800A9;" type="text" class="form-control" name="namaKereta" placeholder="Mataram">
            </div>
            <div class="col-md-4">
                <label for="inputAddress" class="form-label">Tanggal</label>
                <input style="border-color:#A800A9;" type="date" class="form-control" name="tanggal" placeholder="30/11/2022">
            </div>
            <div class="col-md-4">
                <label for="inputAddress2" class="form-label">Waktu Datang</label>
                <input style="border-color:#A800A9;" type="time" class="form-control" name="datang" placeholder="23:56">
            </div>
            <div class="col-md-4">
                <label for="inputCity" class="form-label">Waktu Tiba</label>
                <input style="border-color:#A800A9;" type="time" class="form-control" name="tiba" placeholder="03:56">
            </div>
            <div class="col-md-6">
                <label for="inputState" class="form-label">Asal</label>
                <input style="border-color:#A800A9;" type="text" class="form-control" name="asal" placeholder="Jakarta"></input>
            </div>
            <div class="col-md-6">
                <label for="inputZip" class="form-label">Tujuan</label>
                <input style="border-color:#A800A9;" type="text" class="form-control" name="tujuan" placeholder="Solo">
            </div>
            <div class="col-md-4">
                <label for="inputZip" class="form-label">Status</label>
                <select style="border-color:#A800A9;" class="form-select" aria-label="Default select example" name="status">
                    <option value="tersedia">Tersedia</option>
                    <option value="tidak tersedia">Tidak Tersedia</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="inputZip" class="form-label">Class</label>
                <select style="border-color:#A800A9;" class="form-select" aria-label="Default select example" name="class">
                    <?php foreach ($classes as $class) : ?>
                        <option value="<?php echo $class['id_class'] ?>"><?php echo $class['nama_class'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <button style="margin-top: 2rem;" type="submit" name="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>

    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#A800A9" fill-opacity="1" d="M0,224L12,213.3C24,203,48,181,72,160C96,139,120,117,144,128C168,139,192,181,216,208C240,235,264,245,
            288,256C312,267,336,277,360,245.3C384,213,408,139,432,122.7C456,107,480,149,504,160C528,171,552,149,576,133.3C600,117,624,107,
            648,122.7C672,139,696,181,720,165.3C744,149,768,75,792,53.3C816,32,840,64,864,80C888,96,912,96,936,122.7C960,149,984,203,1008,
            197.3C1032,192,1056,128,1080,96C1104,64,1128,64,1152,58.7C1176,53,1200,43,1224,48C1248,53,1272,75,1296,85.3C1320,96,1344,96,1368,
            101.3C1392,107,1416,117,1428,122.7L1440,128L1440,320L1428,320C1416,320,1392,320,1368,320C1344,320,1320,320,1296,320C1272,320,1248,
            320,1224,320C1200,320,1176,320,1152,320C1128,320,1104,320,1080,320C1056,320,1032,320,1008,320C984,320,960,320,936,320C912,320,888,
            320,864,320C840,320,816,320,792,320C768,320,744,320,720,320C696,320,672,320,648,320C624,320,600,320,576,320C552,320,528,320,504,320C480,
            320,456,320,432,320C408,320,384,320,360,320C336,320,312,320,288,320C264,320,240,320,216,320C192,320,168,320,144,320C120,320,96,320,72,320C48,320,24,
            320,12,320L0,320Z">
        </path>
    </svg>

</body>

</html>