<?php
session_start();

require '../config/config.php';

if (isset($_SESSION['login'])) {
    header("Location: layanan.php");
    exit;
}

if (isset($_POST['submit'])) {
    // var_dump(register($_POST)); return;

    switch (register($_POST)) {
        case '-1':
            echo "<script>
                alert('NIK sudah digunakan!')
                document.location.href='registrasi.php';    
            </script>";
            break;

        case '-2':
            echo "<script>
                    alert('Username sudah digunakan!')
                    document.location.href='registrasi.php';    
                </script>";
            break;

        case '-3':
            echo "<script>
                    alert('NIK harus 16 digit!')
                    document.location.href='registrasi.php';    
                </script>";
            break;

        case '-4':
            echo "<script>
                    alert('Password dan Konfirmasi Password tidak sama!')
                    document.location.href='registrasi.php';    
                </script>";
            break;

        case '-5':
            echo "<script>
                    alert('Nama tidak boleh mengandung angka!')
                    document.location.href='registrasi.php';    
                </script>";
            break;

        default:
            echo "<script>
                    alert('User baru berhasil ditambahkan!')
                    document.location.href='login.php';    
                </script>";
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styleNav.css">
    <link rel="stylesheet" href="../css/style.css">


    <title>Document</title>
</head>

<body>
    <!--Boostrab Navigasi Start-->
    <nav class="navbar navbar-expand-lg navbar-dark bg-light sticky-top">
        <!--gunakan fiixed-top agar navbarnya tetap kelihatan bila kita scroll-->
        <div class="container-fluid">
            <img src="../img/logo.png" alt="logo" style="margin: 30px 0 0 0;">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse">
                <ul>
                    <li><a href="home.php">Home </a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="kontak.php">Service</a></li>

                </ul>
                <div class="content">
                    <button class="cn"><a href="login.php">LOGIN</a></button>
                </div>
            </div>
        </div>
    </nav>
    <h1></h1>
    <br>
    <div class="container">
        <form action="" method="POST" class="login-email">
            <p style="font-size:2rem; font-weight:850;" align="center">REGISTRASI</p> <br>
            <div class="input-group">
                <input type="text" placeholder="NIK" name="idMember">
            </div>
            <div class="input-group">
                <input type="text" placeholder="Nama" name="nama">
            </div>
            <div class="input-group">
                <input type="text" placeholder="No Telepon" name="noTelepon">
            </div>
            <div class="input-group">
                <input type="text" placeholder="Username" name="username">
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" id="password" name="password">
            </div>
            <div class="input-group">
                <input type="password" placeholder="Confirm Password" id="password2" name="password2">
            </div>
            <div class="input-group">
                <button name="submit" id="submit" class="btn">Register
            </div>
            <P class="login-register-text">Have an Account?<a href="login.php">Login</a></P>
    </div>
    </form>
</body>

</html>