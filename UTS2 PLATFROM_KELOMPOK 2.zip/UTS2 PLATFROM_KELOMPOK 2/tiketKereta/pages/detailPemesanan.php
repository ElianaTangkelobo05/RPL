<?php
session_start();

require '../config/config.php';

if (!isset($_SESSION['login'])) {
  header("Location: login.php");
  exit;
}


$pemesanan = getPemesananUser($_GET['idMember']);
$member = getMember($_SESSION)[0];

// var_dump($member);
// return;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" 
  rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <title>Detail Pemesanan</title>
</head>
<body>
  <nav class="navbar " style=" background-color: #d825df;">
    <div class="container">
      <a class="navbar-brand text-white" href="#">
        <p>E-Tiket</p>
      </a>
    </div>
  </nav>

  <img src="../img/logo.png" class="rounded mx-auto d-block" style="margin-top:5rem;">

  <div class="" style="border: 1px solid black; margin-left:12rem; margin-right:12rem;">
    <h6>Data Pemesanan</h6>

    <div class="mb-3 " style="margin-left:5rem; margin-right:15rem;">
      <label for="nama" class="form-label">Nama</label>
      <input style="border-color:black;" type="text" class="form-control" id="nama" aria-describedby="emailHelp" value="<?= $member['nama']?>" disabled>

      <div class="mb-3">
        <label for="nik" class="form-label">NIK</label>
        <input style="border-color:black;" type="text" class="form-control" id="nik" value="<?= $member['idMember']?>" disabled>
      </div>
      <div class="mb-3">
        <label for="telp" class="form-label">No Telpon</label>
        <input style="border-color:black;" type="text" class="form-control" id="telp" value="<?= $member['noTelepon']?>" disabled>
      </div>
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input style="border-color:black;" type="text" class="form-control" id="username" value="<?= $member['username']?>" disabled>
      </div>
    </div>
  </div>

  <div style="border: 1px solid black; margin-left:12rem; margin-right:12rem; margin-top:2rem;">
    <h6>Data Perjalanan</h6>

    <table class="table">
      <thead>
        <tr>
          <th scope="col">Id Jadwal</th>
          <th scope="col">Nama Kereta</th>
          <th scope="col">Tanggal</th>
          <th scope="col">Waktu</th>
          <th scope="col">Asal</th>
          <th scope="col">Tujuan</th>
          <th scope="col">Class</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($pemesanan as $pesan) : ?>
          <tr>
            <th scope="row"><?php echo $pesan['id_jadwal'] ?></th>
            <td><?php echo $pesan['nama_kereta'] ?></td>
            <td><?php echo $pesan['tanggal'] ?></td>
            <td><?php echo $pesan['waktu_datang'] ?> - <?php echo $pesan['waktu_tiba'] ?></td>
            <td><?php echo $pesan['asal'] ?></td>
            <td><?php echo $pesan['tujuan'] ?></td>
            <td><?php echo $pesan['nama_class'] ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>

  <div style="border: 1px solid black; margin-left:12rem; margin-right:12rem; margin-top:2rem;">
    <h6>Data Pemesanan</h6>

    <table class="table">
      <thead>
        <tr>
          <th scope="col">No Receipt</th>
          <th scope="col">Id Penumpang</th>
          <th scope="col">Nama Penumpang</th>
          <th scope="col">Id Member</th>
          <th scope="col">No Kursi</th>
          <th scope="col">Tarif</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($pemesanan as $pesan) : ?>
          <tr>
            <th scope="row"><?php echo $pesan['no_receipt'] ?></th>
            <td><?php echo $pesan['id_penumpang'] ?></td>
            <td><?php echo $pesan['nama_penumpang'] ?></td>
            <td><?php echo $pesan['id_member'] ?></td>
            <td><?php echo $pesan['no_kursi'] ?></td>
            <td><?php echo $pesan['tarif'] ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

  </div>
  <a href="layanan.php" type="button" class="btn btn-primary" style="float:right; margin-right:5rem;">Selesai</a>

</body>

</html>