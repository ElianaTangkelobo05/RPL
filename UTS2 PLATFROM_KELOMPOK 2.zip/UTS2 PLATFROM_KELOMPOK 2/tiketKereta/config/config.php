<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "tiket_kereta";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}
echo "";

function register($data)
{
	global $conn;

	$idMember = $data['idMember'];
	$nama = $data['nama'];
	$noTelepon = $data['noTelepon'];
	$username = $data['username'];
	$password = $data['password'];
	$password2 = $data['password2'];

	$checkNIK = "SELECT * FROM member WHERE idMember = '$idMember'";
	$resultNIK = mysqli_query($conn, $checkNIK);

	$checkUsername = "SELECT * FROM member WHERE username = '$username'";
	$resultUsername = mysqli_query($conn, $checkUsername);

	if (mysqli_num_rows($resultNIK) == 1) {
		return -1; // nik exist
	}

	if (mysqli_num_rows($resultUsername) == 1) {
		return -2; // username exist
	}

	if (strlen($idMember) != 16) {
		return -3; // panjang nik
	}

	if ($password != $password2) {
		return -4; // check pass
	}

	if (!preg_match("/^[a-zA-Z]*$/", trim($nama))) {
		return -5; // check nama mengandung angka
	}

	$hash = password_hash($password, PASSWORD_DEFAULT);
	mysqli_query($conn, "INSERT INTO member VALUES ('$idMember','$nama','$noTelepon','$username', '$hash')");
	return mysqli_affected_rows($conn);
}

function login($data)
{
	global $conn;

	$username = $data['username'];
	$password = $data['password'];


	$queryPass = "SELECT password FROM member WHERE username = '$username';";
	$results = mysqli_query($conn, $queryPass);

	$row = mysqli_fetch_assoc($results);
	if (mysqli_num_rows($results) > 0) {
		$passwordVerif = password_verify($password, $row['password']);
		if ($passwordVerif) {
			return 1;
		}
	} else {
		return 0;
	}
}

function getMember($data)
{
	global $conn;

	$member = $data['user'];

	$query = "SELECT * FROM member WHERE idMember = $member";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function getIdMemberByUsername($data)
{
	global $conn;

	$member = $data;

	$query = "SELECT * FROM member WHERE username = '$member'";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows[0]['idMember'];
}


function tambahJadwal($data)
{
	global $conn;

	$id = $data['id'];
	$namaKereta = $data['namaKereta'];
	$tanggal = $data['tanggal'];
	$datang = $data['datang'];
	$tiba = $data['tiba'];
	$asal = $data['asal'];
	$tujuan = $data['tujuan'];
	$status = $data['status'];
	$class = $data['class'];

	$query = "INSERT INTO `jadwal` (`id_Jadwal`, `nama_Kereta`, `tanggal`, `waktu_Datang`, `waktu_Tiba`, `asal`, `tujuan`, `status`, `id_class`) 
						VALUES ('$id', '$namaKereta', '$tanggal', '$datang', '$tiba', '$asal', '$tujuan', '$status', '$class');";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function editJadwal($data, $idJadwal)
{
	global $conn;

	$id = $data['id'];
	$namaKereta = $data['namaKereta'];
	$tanggal = $data['tanggal'];
	$datang = $data['datang'];
	$tiba = $data['tiba'];
	$asal = $data['asal'];
	$tujuan = $data['tujuan'];
	$status = $data['status'];
	$class = $data['class'];

	$query = "UPDATE `jadwal` 
						SET `id_Jadwal` = '$id',
								`nama_Kereta` = '$namaKereta',
								`tanggal` = '$tanggal',
								`waktu_Datang` = '$datang',
								`waktu_Tiba` = '$tiba',
								`asal` = '$asal',
								`tujuan` = '$tujuan',
								`status` = '$status',
								`id_class` = '$class'
						WHERE `id_jadwal` = '$idJadwal';";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function getJadwal($id)
{
	global $conn;

	$query = "SELECT * FROM jadwal WHERE id_Jadwal = '$id'";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function getClass()
{
	global $conn;

	$query = "SELECT * FROM class";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}


function showJadwal()
{
	global $conn;

	$query = "SELECT j.*, c.nama_class, c.tarif, TIMEDIFF(j.waktu_tiba, j.waktu_datang) as 'durasi'
	FROM jadwal as j
	JOIN class as c ON j.id_class = c.id_class; ";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function showTiket($asal, $tujuan, $tanggal)
{
	global $conn;

	$query = "SELECT j.*, c.nama_class, c.tarif, TIMEDIFF(j.waktu_tiba, j.waktu_datang) as 'durasi'
	FROM jadwal as j
	JOIN class as c ON j.id_class = c.id_class
	WHERE j.asal = '$asal' && j.tujuan = '$tujuan' && j.tanggal = '$tanggal'; ";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function showTiketId($data)
{
	global $conn;

	$query = "SELECT j.*, c.nama_class, c.tarif, TIMEDIFF(j.waktu_tiba, j.waktu_datang) as 'durasi'
	FROM jadwal as j
	JOIN class as c ON j.id_class = c.id_class
	WHERE id_jadwal = '$data'; ";

	// $query = "SELECT * FROM jadwal WHERE id_jadwal = '$data'";
	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function getAsal()
{
	global $conn;

	$query = "SELECT DISTINCT asal FROM jadwal;";

	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function getTujuan()
{
	global $conn;

	$query = "SELECT DISTINCT tujuan FROM jadwal;";

	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function getSeat()
{
	global $conn;

	$query = "SELECT * FROM kursi;";

	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

function pemesanan($post, $jadwals, $member)
{
	global $conn;

	$kursi = $post['seat'];
	$jadwal = $jadwals[0]['id_jadwal'];
	$idPenumpang = $post['id_penumpang'];
	$namaPenumpang = $post['nama_penumpang'];
	if ($idPenumpang == '' && $namaPenumpang == '') {
		$harga = $jadwals[0]['tarif'];
	} else {
		$harga = $jadwals[0]['tarif'];
	}
	$idMember = $member['idMember'];

	$query = "INSERT INTO `pemesanan` (`no_receipt`, `no_kursi`, `id_jadwal`, `id_penumpang`, `nama_penumpang`, `total_harga`, `id_member`) 
						VALUES (NULL, '$kursi', '$jadwal', '$idPenumpang', '$namaPenumpang', '$harga', '$idMember');";

	mysqli_query($conn, $query);

	return mysqli_affected_rows($conn);
}

function getPemesananUser($id)
{
	global $conn;

	$query = "SELECT m.nama, p.*, j.*, c.*
						FROM pemesanan AS p
						JOIN jadwal AS j ON p.id_jadwal = j.id_jadwal
						JOIN class AS c ON j.id_class = c.id_class
						JOIN member AS m ON p.id_member = m.idMember
						WHERE p.id_member = $id;";

	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}

// function cariPemesanan($nama)
// {
// 	global $conn;

// 	$query = "SELECT m.nama, p.*, j.*, c.*
// 						FROM pemesanan AS p
// 						JOIN jadwal AS j ON p.id_jadwal = j.id_jadwal
// 						JOIN class AS c ON j.id_class = c.id_class
// 						JOIN member AS m ON p.id_member = m.idMember
// 						WHERE p.nama_penumpang = '$nama';";

// 	$results = mysqli_query($conn, $query);

// 	$rows = [];

// 	while ($row = mysqli_fetch_assoc($results)) {
// 		$rows[] = $row;
// 	}

// 	return $rows;
// }

function getKursiReserved($idJadwal)
{
	global $conn;

	// $query = "SELECT no_kursi
	// 					FROM pemesanan as p
	// 					JOIN jadwal as j ON p.id_jadwal = j.id_jadwal
	// 					WHERE j.id_jadwal = '$idJadwal';";

	$query = "SELECT no_kursi FROM kursi WHERE no_kursi NOT IN (SELECT no_kursi FROM pemesanan WHERE id_jadwal = '$idJadwal');";

	$results = mysqli_query($conn, $query);

	$rows = [];

	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	}

	return $rows;
}
